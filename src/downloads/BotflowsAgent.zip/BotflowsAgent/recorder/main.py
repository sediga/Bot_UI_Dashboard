import asyncio
import json
from pathlib import Path
from playwright.async_api import async_playwright
import sys
import os

recorded_events = []

# Base directory logic (works with PyInstaller's _MEIPASS or normal path)
BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).parent.resolve()))
script_path = Path(BASE_DIR) / "javascript/recorder.bundle.js"
print(f"Looking for JS at runtime: {script_path}")
print("Exists at runtime?", script_path.exists())

log_path = Path("../dataset/selector_logs.jsonl")
live_events_log = Path("../dataset/live_events.jsonl")
script_path = BASE_DIR / "javascript" / "recorder.bundle.js"
output_path = BASE_DIR / Path("../recordings/recorded_actions.json")

print(f"Injecting script from: {script_path.resolve()}")
if not script_path.exists():
    raise FileNotFoundError(f"Embedded JS file not found: {script_path}")

# Ensure output directories exist
os.makedirs(log_path.parent, exist_ok=True)

# Load existing recordings
recorded_actions_json = {}
if output_path.exists():
    content = output_path.read_text(encoding="utf-8").strip()
    recorded_actions_json = json.loads(content) if content else {}

def append_event(event):
    with open(live_events_log, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")

async def handle_event(source, event):
    recorded_events.append(event)
    append_event(event)
    print("Recorded:", event)

async def handle_log(source, log_data):
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            json.dump(log_data, f)
            f.write("\n")
        print("Logged selector data.")
    except Exception as e:
        print(f"Failed to log selector: {e}")

async def handle_url_change(source, new_url):
    print(f"Detected SPA URL change to: {new_url}")
    page = source._context.pages[0]
    await reinject_script(page)

async def inject_script(page):
    try:
        await page.add_init_script(script_path.read_text(encoding="utf-8"))
        await page.evaluate("window.__recorderInjected = true")
        print("Script injected")
    except Exception as e:
        print(f"Injection failed: {e}")

async def reinject_script(page):
    try:
        is_injected = await page.evaluate("() => window.__recorderInjected === true")
        if not is_injected:
            print("Reinjecting recorder after navigation...")
            await page.evaluate(script_path.read_text(encoding="utf-8"))
            await page.evaluate("window.__recorderInjected = true")
        else:
            print("Recorder already present")
    except Exception as e:
        print(f"Reinjection failed: {e}")

async def run(args=None):
    print("Starting recorder...")
    if args is None:
        args = sys.argv[1:]
    url = args[0] if args else input("Enter URL: ").strip()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False, slow_mo=50)
        context = await browser.new_context()

        await context.expose_binding("sendEventToPython", handle_event)
        await context.expose_binding("sendUrlChangeToPython", handle_url_change)
        await context.expose_binding("sendLogToPython", handle_log)

        page = await context.new_page()
        await inject_script(page)
        await page.goto(url)

        try:
            delete_stop_file()
            print("Recording... ")
            await wait_for_stop()
        finally:
            deduped = deduplicate_events(recorded_events)
            recorded_actions_json[url] = deduped
            output_path.write_text(json.dumps(recorded_actions_json, indent=2))
            print(f"Saved {len(deduped)} events to {output_path}")
            await browser.close()

async def wait_for_stop():
    stop_file = Path("recordings/stop.flag")
    print("Waiting for stop signal...")
    while not stop_file.exists():
        await asyncio.sleep(1)
    print("Stop flag detected.")
    stop_file.unlink(missing_ok=True)

async def delete_stop_file():
    stop_file = Path("recordings/stop.flag")
    if stop_file.exists():
        print("Stop flag detected... deleting stop file.")
        stop_file.unlink(missing_ok=True)

def deduplicate_events(events, time_threshold_ms=200):
    seen, deduped = [], []
    for event in events:
        if event["action"] != "click":
            deduped.append(event)
            continue
        ts = event["timestamp"]
        if any(e["action"] == "click" and abs(e["timestamp"] - ts) <= time_threshold_ms for e in seen):
            continue
        deduped.append(event)
        seen.append(event)
    return deduped

if __name__ == "__main__":
    print("main.py executing")
    print(f"sys.argv: {sys.argv}")
    asyncio.run(run())
